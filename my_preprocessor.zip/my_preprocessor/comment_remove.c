#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"functions.h"
#include"extern_variable.h"

static int flag=0;

int check_alphabet_number(char *ch)
{
	while(*ch)
	{
		if((*ch>=48) && (*ch<=57))
			return 1;
		else if((*ch>=65)&&(*ch<=90))
			return 1;
		else if((*ch>=97)&&(*ch<=122))
			return 1;
		else if(*ch=='{'||*ch=='}')
			return 1;
		ch++;
	}
	return 0;
}
int one_line_comment_remove(char*str)
{
	*tptr++='\n';
//	while(*tptr)
		*tptr='\0';
	if(check_alphabet_number(str)==0)
		*str='\0';
	flag=0;
}
int mult_line_comment_remove(char*str)
{
	if((tptr1=strstr(str,"*/"))!=NULL)
	{
		*tptr++='\n';
		while(tptr!=(tptr1+1))
			*tptr++='\0';
		if(check_alphabet_number(str)==0)
			*str='\0';
		flag=0;
	}
	else if(flag==1)
		*str='\0';
	else
	{
		*tptr++='\n';
		while(*tptr)
			*tptr++='\0';
		if(check_alphabet_number(str)==0)
			*str='\0';
		flag=1;
	}
}

int check_comment(char*str)
{
	if((tptr=strstr(str,"/*"))!=NULL)
	{
		mult_line_comment_remove(str);
		return 1;
	}
	else if(flag==1)
	{
		tptr=str;
		mult_line_comment_remove(str);
		return 1;
	}            
	if((tptr=strstr(str,"//"))!=NULL)
        {
                one_line_comment_remove(str);
                return 1;
        }
	return 0;
}
