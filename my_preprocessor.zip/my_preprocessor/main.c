#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"functions.h"
#include"extern_variable.h"
#define DEBUG
int main(int argc,const char*argv[])
{
	get_i_file_name(argc,argv[1]);  // get .i file name
	main_fptr=fopen(argv[1],"r");	//.c file open in read mode
	if(main_fptr==NULL)
	{
		printf("ERROR!! : unable to open %s file\n",argv[1]);
		exit(0);
	}
	i_fptr=fopen(i_filename,"w");	//.i file open in write mode
	
	preprocessor_function(main_fptr);
#ifdef DEBUG	
	for(int i=0;i<=macro_count;i++)
	{
		printf("macro_name  : ");
		puts(macro_name[i]);
		printf("macro_value : ");
		puts(macro_value[i]);
	}
	printf("\n");
	for(int i=0;i<=mfc;i++)
	{
		printf("mfc name     : ");
		puts(macro_function[i].name);
		printf("mfc function : ");
		puts(macro_function[i].function);
		printf("mfc value    : ");
		puts(macro_function[i].value);
	}
    printf("mfc = %d\n",mfc);	
#endif
	fclose(main_fptr);
	fclose(i_fptr);
}
int preprocessor_function(FILE*c_fptr)
{
	while(fgets(str,99,c_fptr)!=NULL)
	{
		str_size=strlen(str);
		if(check_comment(str)==1)    // remove all the comments from string 
		{
			if(*str=='\0')       // if string is empty then skip other process
				continue;
		}
		if(strstr(str,"#")!=NULL)   // check in string the given 
		{	                   // instruction is about the preprocessor directory
			for(int i=0;i<=PRE_DIR_COUNT;i++)
			{
				if(strstr(str,pre_dir[i])!=NULL)
				{
					pre_dir_function(i,c_fptr);  // preprocessor directory functions
					break;
				}
			}
			continue;
		}
		else
		{
			macro_replace();          // single macro replaced
			macro_function_replace();  // macro function get replaced
		}
		fputs(str,i_fptr);
	}
}
int pre_dir_function(int index,FILE*src_fptr)
{
	switch(index)
	{
		case 0:header_inclusion();
		       break;
		case 1:macro_save(src_fptr);
		       break;
	/*	case 2:if_macro_not_define(src_fptr);
		       break;
		case 3:check_macro_defined();
		       break;
		case 4:
		case 5:
		case 6:
		case 7:
		case 8:
		case 9:undefine_the_macro();
		       break;
		case 10:
	*/
	}
}


