#ifndef _HEADER_LUT_H
#define _HEADER_LUT_H

const char*header_LUT[]={"aio.h","err.h","grp.h","mqueue.h","printf.h","shadow.h","thread_db.h","aliases.h","errno.h",
                         "gshadow.h","proc_service.h","signal.h","threads.h","alloca.h","error.h","iconv.h","time.h",
                         "argp.h","execinfo.h","ifaddrs.h","pthread.h","spawn.h","ttyent.h","argz.h","fcntl.h",
                         "inttypes.h","pty.h","stab.h","uchar.h","ar.h","features.h","pwd.h","stdbit.h","ucontext.h",
                         "features-time64.h","langinfo.h","netdb.h","stdc-predef.h","ulimit.h","fenv.h","lastlog.h",
                         "stdint.h","unistd.h","assert.h","finclude","libgen.h","re_comp.h","stdio_ext.h","utime.h",
                         "byteswap.h","fmtmsg.h","libintl.h","regex.h","stdio.h","utmp.h","fnmatch.h","limits.h",
                         "regexp.h","stdlib.h","utmpx.h","complex.h","fstab.h","link.h","string.h","values.h","cpio.h",
                         "fts.h","resolv.h","strings.h","crypt.h","ftw.h","locale.h","sudo_plugin.h","wait.h","ctype.h",
                         "gawkapi.h","malloc.h","syscall.h","wchar.h","dirent.h","gconv.h","math.h","nl_types.h",
                         "sched.h","sysexits.h","wctype.h","dlfcn.h","mcheck.h","nss.h","syslog.h","wordexp.h",
                         "getopt.h","memory.h","obstack.h","earch.h","tar.h","elf.h","glob.h","semaphore.h","termio.h",
                         "endian.h","gnumake.h","mntent.h","paths.h","setjmp.h","termios.h","envz.h","gnu-versions.h",
                         "monetary.h","poll.h","sgtty.h","tgmath.h"
                        };
#endif

