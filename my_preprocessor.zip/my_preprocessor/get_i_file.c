#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"functions.h"
#include"extern_variable.h"

void check_cmd(int argc)
{
	if(argc<2)
	{
		printf("ERROR!! : provide executable and .c file\n");
		exit(0);
	}
}
void get_i_file_name(int argc,const char*argv)
{
	char *ptr=NULL;
	check_cmd(argc);
	i_filename=calloc(1,strlen(argv)+1);
	if(i_filename==NULL)
	{
		printf("ERROR!! : dynamic memory allocation fail\n");
		exit(0);
	}
	strcpy(i_filename,argv);
	if((ptr=strstr(i_filename,".c"))!=NULL)
		strcpy(ptr,".i");
	else
	{
		printf("ERROR!! : provide executable and .c file\n");
		exit(0);
	}
	ptr=NULL;
}
		
