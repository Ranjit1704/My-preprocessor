#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"functions.h"
#include"extern_variable.h"

#define DEBUG1 1

int mfc_flag=0;
int find_macro_name()
{
	macro_count++;
	macro_name=realloc(macro_name,sizeof(char**)*(macro_count+1));
	macro_name[macro_count]=calloc(1,sizeof(str));
	for(int i=0;!(*ptr==' '||*ptr=='\n'||*ptr=='\t');i++)
	{
		macro_name[macro_count][i]=*ptr;
			ptr++;
	}
	macro_name[macro_count]=realloc(macro_name[macro_count],strlen(macro_name[macro_count])+1);    
}
int macro_value_save()
{
	macro_value=realloc(macro_value,sizeof(char**)*(macro_count+1));
	while(*ptr)
	{
		if(!((*ptr==' ')||(*ptr=='\t')||(*ptr=='\n')))
			break;
		ptr++;
	}
        macro_value[macro_count]=calloc(1,strlen(ptr));
	if((*ptr=='\n')||(*ptr=='\0'))
        {
                macro_value[macro_count]=" ";
        }
	else
	{
		for(int i=0;*ptr&&(*ptr!='\n');i++)
		{
			macro_value[macro_count][i]=*ptr;
			ptr++;
		}
	}
//	macro_value[macro_count]=realloc(macro_value[macro_count],strlen(macro_value[macro_count])+1);
}
int macro_replace()
{
	for(int i=0;i<=macro_count;i++)
        {
        	if((m_replace=strstr(str,macro_name[i]))!=NULL)
                {
                	 strcpy(temp,m_replace+strlen(macro_name[i]));
                         strcpy(m_replace,macro_value[i]);
                         strcpy(m_replace+strlen(m_replace),temp);
                         if(str_size>strlen(str))
                         {
                        	 for(int i=strlen(str)-1;i<str_size;i++)
                                 	str[i]=' ';
                                 str[str_size-1]='\n';
                                 str[str_size]='\0';
                         }
			 break;
		}
	}
}
int macro_function_save(FILE*src_fptr)
{
	mfc_flag=0;  // for the next checking macro function flag is disabled 
		     // if the macro funtion occur then it enabled
	mfc++;  // macro function count initially (-1)  
	macro_function=(MACRO*)realloc(macro_function,sizeof(MACRO)*(mfc+1));
	int i=0;
	for(i=0;*ptr!='(';i++)
		temp[i]=*ptr++;
	temp[i]='\0';
	strcpy(macro_function[mfc].name,temp);  // name of macro function is saved
	for(i=0;*ptr!=')';i++)
		temp[i]=*ptr++;
	temp[i++]=*ptr++;
	temp[i]='\0';
	strcpy(macro_function[mfc].function,temp); // function paremeter is saved
	while(((*ptr==' ')||(*ptr=='\n')||(*ptr=='\t'))&&*ptr)
		ptr++;
	if((*ptr=='\n')||(*ptr=='\0'))
		strcpy(macro_function[mfc].value," ");
	else
	{
		i=0;
		while(strstr(ptr,"\\")!=NULL)
		{
			for( ;*ptr&&*ptr!='\\';i++)
				temp[i]=*ptr++;
			if(fgets(str,99,src_fptr)!=NULL)
			{
				ptr=str;
				while((*ptr=='\t')||(*ptr==' '))
					ptr++;
			}
			else
				break;
		}
		for( ;*ptr&&*ptr!='\n';i++)
			temp[i]=*ptr++;
		temp[i]='\0';
		strcpy(macro_function[mfc].value,temp);  // macro expansion is saved
	}	
}

int find_macro_function_parameter(int index)
{
	int count=1;
	char*ptr=macro_function[index].function;
	while((ptr=strstr(ptr,","))!=NULL)
	{
		count++;
		ptr++;
	}
	return count;
}

int macro_function_replace()
{
	char*m_replace=NULL;
	for(int i=0;i<=mfc;i++)
	{
		if((m_replace=strstr(str,macro_function[i].name))!=NULL)
		{
#ifdef DEBUG1 
		printf("mfc : %d\ni=%d\n",mfc,i);
		puts(macro_function[i].name);
#endif
			char*tptr=NULL;
			tptr=m_replace;
			while((*tptr++)!='(');
			char*tstr=calloc(1,strlen(tptr)+1);
			int count=find_macro_function_parameter(i);
			char**mf_array=calloc(count,sizeof(char*));
			char**mfp_array=calloc(count,sizeof(char*));
#ifdef DEBUG
			printf("%d\n",count);
			puts(tptr);
			printf("mf_array : %ld\n",sizeof(mf_array[0]));
#endif
			int l=0;
			for(int j=0;j<count;j++)
			{
				char*ptr=NULL;
				int k=0;
				while((*tptr!=',')&&(*tptr!=')'))
				{
					ptr=realloc(ptr,sizeof(char)*(k+1));
					ptr[k++]=*tptr++;
				}
				ptr=realloc(ptr,sizeof(char)*(k+1));
				ptr[k]='\0';
				mf_array[j]=ptr;
				tptr++;
#ifdef DEBUG
			//	puts(tptr);
				puts(mf_array[j]);
				printf("j=%d	ptr=%ld\n",j,sizeof(ptr));
#endif
				char*ptr1=NULL;
				int m=0;
				for( ;macro_function[i].function[l];l++)
				{
					if(macro_function[i].function[l]=='(')
						continue;
					else if((macro_function[i].function[l]==',')||(macro_function[i].function[l]==')'))
					{
						l++;
						break;
					}
					ptr1=realloc(ptr1,sizeof(char)*(m+1));
					ptr1[m++]=macro_function[i].function[l];
					
				}
				ptr1=realloc(ptr1,sizeof(char)*(m+1));
				ptr1[m]='\0';
				mfp_array[j]=ptr1;
				ptr=NULL;
				ptr1=NULL;
			}
#ifdef DEBUG
				puts(mf_array[0]);
				puts(mf_array[1]);
				puts(mfp_array[0]);
				puts(mfp_array[1]);
			//	puts(ptr1);
#endif
			strcpy(tstr,tptr);
			char*temp1=strcpy(temp,macro_function[i].value);
			for(int c=0;c<count;c++)
			{
				if((temp1=strstr(temp1,mfp_array[c]))!=NULL)
				{
					memmove(temp1+(strlen(mf_array[c])),temp1+strlen(mfp_array[c]),strlen(temp1+strlen(mf_array[c]))+1);
					strncpy(temp1,mf_array[c],strlen(mf_array[c]));
				}
			}
			temp[strlen(temp)]='\0';
#ifdef DEBUG
			puts(temp1);
			puts(temp);
			puts(tstr);
#endif
			strcpy(m_replace,temp);
			strcpy(str+strlen(str),tstr);    
#ifdef DEBUG1
			puts(str);
#endif
			free(mf_array);
			free(mfp_array);
			free(tstr);
			mf_array=NULL;
			mfp_array=NULL;
			tstr=NULL;
		break;
		}
	}
}

int macro_save(FILE*src_fptr)
{
	ptr=strstr(str,"define ");
        ptr+=strlen("define ");
        while(*ptr)
        {
                if(((*ptr>=65) && (*ptr<=90))||((*ptr>97) && (*ptr<=122))||(*ptr=='_'))
                        break;
                ptr++;
        }
	for(int i=0;(ptr[i]!='\n'&&ptr[i]!='\t'&&ptr[i]&&ptr[i]!=' ');i++)
	{
		if(ptr[i]=='(')
		{
			mfc_flag=1;
			break;
		}
	}
	if(mfc_flag)
	{
		macro_function_save(src_fptr);
	}
	else
	{
		find_macro_name();
		macro_value_save();
	}
}
