#ifndef _EXTERN_VARIABLE_H
#define _EXTERN_VARIABLE_H

// macro
#define PRE_DIR_COUNT 10

//FILE pointers
extern FILE*main_fptr,*i_fptr;
extern FILE*header_fptr;

//char arrays
extern char str[100],temp[100];

//char pointers
extern char*m_replace;
extern char*i_filename;
extern char*header_name;
extern char *path;
extern char*ptr;

// char double pointers
extern char**macro_name;
extern char**macro_value;

// char temperory pointers
extern char*tptr;
extern char*tptr1;

// array of pointers
extern char*pre_dir[];

//integer variables
extern int str_size;
extern int macro_count;
extern int mfc;   //macro_function_count

// structure declaration
typedef struct macro_function
{
        char name[100];
        char function[10];
        char value[100];
}MACRO;

// structure pointers
extern MACRO*macro_function;


#endif

