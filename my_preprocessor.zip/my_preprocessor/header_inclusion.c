#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include"header_LUT.h"
#include"functions.h"
#include"extern_variable.h"

char*header_path[]={"","/usr/include/","/usr/include/linux/","/usr/include/x86_64-linux-gnu/"};

int header_inclusion(void)
{
	char*path=NULL;
        strtok(str,"<\"");
        char*header_name=strtok(NULL,">\"");
	FILE*header_fptr=NULL;
	int i=0;
	do
	{
		path=realloc(path,(strlen(header_name)+strlen(header_path[i]))+1);
		strcpy(path,header_path[i++]);
		strcat(path,header_name);
		header_fptr=fopen(path,"r");
		if(i==4)
			break;
	}while(header_fptr==NULL);
	if(header_fptr==NULL)
	{
		printf("ERROR!! : failed to open %s header file\n",header_name);
		puts(path);
		exit(0);
	}
	else
		puts(path);
	inclusion(header_fptr);
	fclose(header_fptr);
	free(path);
}

int inclusion(FILE*header_fptr)
{
	while(fgets(str,99,header_fptr)!=NULL)
	{
		int flag=1;
		if(check_comment(str)==1)
		{
			if(*str=='\0')
				continue;
		}
		if(strstr(str,"#")!=NULL)
		{
			if(strstr(str,"define ")!=NULL)
			{
				macro_save(header_fptr);
				continue;
			}
	/*		else if(strstr(str,"ifndef ")!=NULL)
			{
				if_macro_not_define(header_fptr);
				continue;
			}
	*/	}
		fputs(str,i_fptr);
	}
}

