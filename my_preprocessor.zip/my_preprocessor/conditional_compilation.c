
//char*pre_dir[]={"include","define ","ifndef ","ifdef ","endif","elif","if","else","undef ","pragma"};

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"extern_variable.h"
#include"functions.h"

int if_macro_not_define(FILE*src_fptr)
{
	int i,j;
	for(i=0;i<=macro_count;i++)
	{
		if(strstr(str,macro_name[i])!=NULL)
			break;
	}
	for(j=0;j<=mfc;j++)
	{
		if(strstr(str,macro_function[j].name)!=NULL)
			break;
	}
	if((i>macro_count)&&(j>mfc))
		return 1;	
	else
	{
		while(fgets(str,99,src_fptr)!=NULL)
		{
			if((strstr(str,"#")!=NULL)&&(strstr(str,"endif")!=NULL))
                                break;
		}
	}	
}
