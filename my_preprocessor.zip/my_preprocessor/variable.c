#include<stdio.h>
#include<stdlib.h>
#include<string.h>

//FILE pointers
FILE*main_fptr=NULL,*i_fptr=NULL;
FILE*header_fptr=NULL;

//char arrays
char str[100],temp[100];

//char pointers
char*m_replace=NULL;
char*i_filename=NULL;
char*header_name=NULL;
char *path=NULL;
char*ptr=NULL;

// char double pointers
char**macro_name=NULL;
char**macro_value=NULL;

//structure
typedef struct macro_function
{
	char name[100];
	char function[10];
	char value[100];
}MACRO;

// structure pointers
MACRO*macro_function=NULL;

// char temperory pointers
char*tptr=NULL;
char*tptr1=NULL;

// array of pointers
char*pre_dir[]={"include","define ","ifndef ","ifdef ","endif","elif","if","else","undef ","pragma"};

//integer variables
int str_size;
int macro_count=-1;
int mfc=-1;   // macro_function_count

