#ifndef _FUNCTIONS_H
#define _FUNCTIONS_H

// main.c file functions 
int preprocessor_function(FILE*c_fptr);
int pre_dir_function(int index,FILE*src_fptr);

// get_i_file.c functions
void check_cmd(int argc);
void get_i_file_name(int argc,const char*argv);

// comment_remove.c functions
int check_alphabet_number(char *ch);
int one_line_comment_remove(char*str);
int mult_line_comment_remove(char*str);
int check_comment(char*str);

// header_inclusion.c functions
int inclusion(FILE*header_fptr);
int header_inclusion(void);

// macro_replace.c functions
int find_macro_name();
int macro_value_save();
int macro_replace();
int macro_function_save(FILE*src_fptr);
int find_macro_function_parameter(int index);
int macro_function_replace();
int macro_save(FILE*src_fptr);

// conditional_compilation.c function
int if_macro_not_define(FILE*src_fptr);

#endif
