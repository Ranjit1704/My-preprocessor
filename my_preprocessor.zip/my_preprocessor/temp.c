//#include <bits/types/struct_FILE.h>
#include<stdio.h>  //header file
                   //remove this whole line
//#include"header_LUT.h"
//#include<features.h>
#define MACRO 100
#define REMOVE 200
#define SAVE 300
#define ADD(x,y) (x+y)
#define SUB(x,y) (x-y)
int main()
{
	printf("Hello\n"); // hello
	//above line print Hello word
	/* i 
	 * want 
	 * to
	 * remove
	 * it
	 */

	printf("bye\n"); /*now delet from here only*/
	int a=MACRO;
	int b=REMOVE;
	int c=SEEK_CUR;
	int prev=SEEK_SET;
	int end=SEEK_END;
	int a=ADD(a,b);
	int x=15+20-90;
	int z=SUB(c,d);
}
